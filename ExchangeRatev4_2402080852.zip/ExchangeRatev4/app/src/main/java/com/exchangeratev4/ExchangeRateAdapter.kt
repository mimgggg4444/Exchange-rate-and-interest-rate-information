package com.exchangeratev4

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ExchangeRateAdapter(var rates: List<ExchangeRate>) : RecyclerView.Adapter<ExchangeRateAdapter.ViewHolder>() {

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val curUnit: TextView = view.findViewById(R.id.cur_unit)
        val curName: TextView = view.findViewById(R.id.cur_name)
        val exchangeRate: TextView = view.findViewById(R.id.exchange_rate)
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_currency, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val rate = rates[position]
        holder.curUnit.text = rate.cur_unit
        holder.curName.text = rate.cur_nm
        holder.exchangeRate.text = rate.deal_bas_r


    }

    override fun getItemCount() = rates.size



}
