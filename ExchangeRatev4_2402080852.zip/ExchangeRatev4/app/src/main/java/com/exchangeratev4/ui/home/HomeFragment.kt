package com.exchangeratev4.ui.home
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.exchangeratev4.ExchangeRateAdapter
import com.exchangeratev4.ExchangeRateRepository
import com.exchangeratev4.R
import java.text.SimpleDateFormat
import java.util.*


class HomeFragment : Fragment(R.layout.fragment_home) {
    private val viewModel: HomeViewModel by viewModels()
    private lateinit var exchangeRateAdapter: ExchangeRateAdapter
    private lateinit var tvDate: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

//        tvDate = view.findViewById(R.id.tv_date)
        tvDate = view.findViewById(R.id.tv_data)

        // 요일을 추가하기 위한 코드
        val calendar = Calendar.getInstance()
        val format = SimpleDateFormat("EEEE", Locale.KOREAN)
        val dayOfWeek = format.format(calendar.time)

        val repository = ExchangeRateRepository()
        val currentDate = repository.getCurrentDate()

        // 날짜와 요일을 합쳐서 출력
        tvDate.text = "$currentDate, $dayOfWeek. 환율 정보는 11시 이후에 갱신됩니다."

        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)
        exchangeRateAdapter = ExchangeRateAdapter(emptyList())
        recyclerView.adapter = exchangeRateAdapter

        viewModel.exchangeRates.observe(viewLifecycleOwner, { rates ->
            Log.d("HomeFragment", "Received rates: $rates")
            recyclerView.adapter = ExchangeRateAdapter(rates)
        })
    }
}
