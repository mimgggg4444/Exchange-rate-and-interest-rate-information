package com.exchangeratev4
import retrofit2.http.GET
import retrofit2.http.Query

interface ExchangeRateApi {
    @GET("exchangeJSON?authkey=ICjIOiSwUOBLEFXzPBy0ovQ4EoQWTPCV&data=AP01")
    suspend fun getExchangeRates(
        @Query("searchdate") searchdate: String
    ): List<ExchangeRate>
}
