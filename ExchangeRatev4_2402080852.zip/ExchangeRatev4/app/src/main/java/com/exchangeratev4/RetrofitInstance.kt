package com.exchangeratev4

object RetrofitInstance {
}