package com.exchangeratev4.ui.home



import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.exchangeratev4.ExchangeRate
import com.exchangeratev4.ExchangeRateRepository
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {



    private val repository = ExchangeRateRepository()
    val exchangeRates = MutableLiveData<List<ExchangeRate>>()

    init {
        loadExchangeRates()
    }

private fun loadExchangeRates() {
    viewModelScope.launch {
        val rates = repository.getExchangeRates()
        Log.d("HomeViewModel", "Setting rates: $rates")
        exchangeRates.value = rates
    }
}



}
