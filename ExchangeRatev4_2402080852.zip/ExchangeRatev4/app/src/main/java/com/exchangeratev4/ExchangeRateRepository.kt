package com.exchangeratev4


import android.util.Log
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ExchangeRateRepository {
    private val exchangeRateApi: ExchangeRateApi

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://www.koreaexim.go.kr/site/program/financial/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        exchangeRateApi = retrofit.create(ExchangeRateApi::class.java)
    }

    public fun getCurrentDate(): String {
        val currentDate = Date()
        val formatter = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
        return formatter.format(currentDate)
    }

    suspend fun getExchangeRates(): List<ExchangeRate> {
        val cal = Calendar.getInstance(Locale.getDefault())
        val hour = cal.get(Calendar.HOUR_OF_DAY)

        val searchDate = if (hour < 11) getPreviousDate() else getCurrentDate()

        val rates = exchangeRateApi.getExchangeRates(searchDate)
        Log.d("ExchangeRateRepository", "Fetched rates: $rates")
        return rates
    }

    private fun getPreviousDate(): String {
        val cal = Calendar.getInstance(Locale.getDefault())
        cal.add(Calendar.DAY_OF_MONTH, -1)

        val formatter = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
        return formatter.format(cal.time)
    }
}


