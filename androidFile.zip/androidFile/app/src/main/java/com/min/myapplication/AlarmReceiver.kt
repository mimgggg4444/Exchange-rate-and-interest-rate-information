package com.min.myapplication



import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val notificationManager = ContextCompat.getSystemService(context, NotificationManager::class.java) as NotificationManager
        val notificationChannel = NotificationChannel("channelID", "channelName", NotificationManager.IMPORTANCE_DEFAULT)

        notificationManager.createNotificationChannel(notificationChannel)

        // 사용자가 알림을 눌렀을 때 MainActivity를 열도록 하는 Intent를 생성합니다.
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(context, 0, openAppIntent, PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, "channelID")
            .setContentTitle("알람")
            .setContentText("알람이 울립니다.")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentIntent(pendingIntent)  // 알림을 눌렀을 때 실행될 Intent를 설정합니다.
            .setAutoCancel(true)  // 알림을 누르면 자동으로 알림이 사라지도록 합니다.
            .build()

        notificationManager.notify(0, notification)
    }
}


